using System;
using System.Linq;
using System.Windows.Forms;
using Exercise_7.Models.DataLayer;

namespace Exercise_7
{
    public partial class Form1 : Form
    {
      private MMABooksContext context = new MMABooksContext();

    public Form1()
        {
       InitializeComponent();
        }
       private void Form1_Load(object sender, EventArgs e)
        {
            LoadStudents();
        }
        // show all students in the grid
        private void btnDisplayStudents_Click(object sender, EventArgs e)
        {
            LoadStudents();
        }
        
        //add a new student to the database
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (ValidateInput(out int studentId, out DateTime dob))
            {
                try
                {
                    var newStudent = new Student
                    {
                      StudentId = studentId,
                    FirstName = txtFirstName.Text,
                     LastName = txtLastName.Text,
                     DoB = DateOnly.FromDateTime(dob),
                    Major = txtMajor.Text
                    };
                    context.Student.Add(newStudent);
                    context.SaveChanges();
                    MessageBox.Show("Student added successfully!");
                    LoadStudents();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                }
            }
        }
        // modify student record
        private void btnModify_Click(object sender, EventArgs e)
        {
            if (ValidateInput(out int studentId, out DateTime dob))
            {
                try
                {
                  var student = context.Student.Find(studentId);
                  if (student != null)
                  {
                      student.FirstName = txtFirstName.Text;
                      student.LastName = txtLastName.Text;
                     student.DoB = DateOnly.FromDateTime(dob);
                      student.Major = txtMajor.Text;

                      context.SaveChanges();
                      MessageBox.Show("Student updated successfully!");
                       LoadStudents();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                }
            }
        }

        // Click event to delete a student from the database
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewStudent.SelectedRows.Count > 0)
            {
            
                int selectedRowIndex = dataGridViewStudent.SelectedCells[0].RowIndex;
                var student = dataGridViewStudent.Rows[selectedRowIndex].DataBoundItem as Student;

                if (student != null)
                {
                  // Remove the student and save changes
                  context.Student.Remove(student);
                   context.SaveChanges();
                  MessageBox.Show("Student deleted successfully!");
                  LoadStudents();
                }
                
            }
            else
            {
                MessageBox.Show("Please select a student to delete.");
            }
        }

        // validate the input fields
        private bool ValidateInput(out int studentId, out DateTime dob)
        {
            studentId = 0;
            dob = DateTime.MinValue;

            if (!int.TryParse(txtStudentID.Text, out studentId))
            {
                MessageBox.Show("Invalid Student ID.");
                return false;
            }

            // Check if input fields exceed character limit
            if (txtFirstName.Text.Length > 30 || txtLastName.Text.Length > 30 || txtMajor.Text.Length > 30)
            {
                MessageBox.Show("First Name, Last Name, and Major must not exceed 30 characters.");
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtFirstName.Text) ||
                string.IsNullOrWhiteSpace(txtLastName.Text) ||
                string.IsNullOrWhiteSpace(txtMajor.Text) ||
                !DateTime.TryParse(txtDoB.Text, out dob))
            {
                MessageBox.Show("All fields must be filled with valid data.");
                return false;
            }
            if (dob.TimeOfDay != TimeSpan.Zero)
            {
                MessageBox.Show("Date of Birth must not include time.");
                return false;
            }
            return true;
        }

        // Load all students and display in DataGridView
        private void LoadStudents()
        {
          try
            {
                dataGridViewStudent.DataSource = context.Student.ToList();
            }
          catch (Exception ex)
            {
             MessageBox.Show($"Error: {ex.Message}");
            }
        }
        // Clear all input fields 
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtStudentID.Clear();
            txtFirstName.Clear();
            txtLastName.Clear();
            txtMajor.Clear();
            txtDoB.Clear();
            dataGridViewStudent.DataSource = null;
        }

        // Exit the form
        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
