﻿namespace Exercise_7
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
             components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            btnAdd = new Button();
            btnModify = new Button();
            btnDelete = new Button();
            btnClear = new Button();
            btnExit = new Button();
            dataGridViewStudent = new DataGridView();
            txtStudentID = new TextBox();
            lblStudentID = new Label();
            lblFirstName = new Label();
            lblLastName = new Label();
            lblDoB = new Label();
            lblMajor = new Label();
            txtFirstName = new TextBox();
            txtLastName = new TextBox();
            txtDoB = new TextBox();
            txtMajor = new TextBox();
            btnDisplayStudent = new Button();

            ((System.ComponentModel.ISupportInitialize)dataGridViewStudent).BeginInit();
            SuspendLayout();

            // btnAdd
            btnAdd.Location = new Point(74, 228);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(75, 23);
            btnAdd.TabIndex = 17;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;

            // btnModify
            btnModify.Location = new Point(233, 228);
            btnModify.Name = "btnModify";
            btnModify.Size = new Size(75, 23);
            btnModify.TabIndex = 16;
            btnModify.Text = "Modify";
            btnModify.UseVisualStyleBackColor = true;

            // btnDelete
            btnDelete.Location = new Point(416, 228);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(75, 23);
            btnDelete.TabIndex = 15;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;

            // btnClear
            btnClear.Location = new Point(615, 228);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(75, 23);
            btnClear.TabIndex = 14;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;

            // btnExit
            btnExit.Location = new Point(713, 21);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(75, 23);
            btnExit.TabIndex = 13;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;

            // dataGridViewStudent
            dataGridViewStudent.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewStudent.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewStudent.Location = new Point(139, 269);
            dataGridViewStudent.Name = "dataGridViewStudent";
            dataGridViewStudent.ReadOnly = true;
            dataGridViewStudent.Size = new Size(496, 150);
            dataGridViewStudent.TabIndex = 11;

            // txtStudentID
            txtStudentID.Location = new Point(139, 35);
            txtStudentID.Name = "txtStudentID";
            txtStudentID.Size = new Size(100, 23);
            txtStudentID.TabIndex = 10;

            // lblStudentID
            lblStudentID.AutoSize = true;
            lblStudentID.Location = new Point(28, 38);
            lblStudentID.Name = "lblStudentID";
            lblStudentID.Size = new Size(59, 15);
            lblStudentID.TabIndex = 9;
            lblStudentID.Text = "StudentID";

            // lblFirstName
            lblFirstName.AutoSize = true;
            lblFirstName.Location = new Point(28, 89);
            lblFirstName.Name = "lblFirstName";
            lblFirstName.Size = new Size(61, 15);
            lblFirstName.TabIndex = 8;
            lblFirstName.Text = "FirstName";

            // lblLastName
            lblLastName.AutoSize = true;
            lblLastName.Location = new Point(313, 89);
            lblLastName.Name = "lblLastName";
            lblLastName.Size = new Size(60, 15);
            lblLastName.TabIndex = 7;
            lblLastName.Text = "LastName";

            // lblDoB
            lblDoB.AutoSize = true;
            lblDoB.Location = new Point(28, 136);
            lblDoB.Name = "lblDoB";
            lblDoB.Size = new Size(29, 15);
            lblDoB.TabIndex = 6;
            lblDoB.Text = "DoB";

            // lblMajor
            lblMajor.AutoSize = true;
            lblMajor.Location = new Point(28, 179);
            lblMajor.Name = "lblMajor";
            lblMajor.Size = new Size(38, 15);
            lblMajor.TabIndex = 5;
            lblMajor.Text = "Major";

            // txtFirstName
            txtFirstName.Location = new Point(139, 81);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(100, 23);
            txtFirstName.TabIndex = 4;

            // txtLastName
            txtLastName.Location = new Point(416, 86);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(100, 23);
            txtLastName.TabIndex = 3;

            // txtDoB
            txtDoB.Location = new Point(139, 128);
            txtDoB.Name = "txtDoB";
            txtDoB.Size = new Size(100, 23);
            txtDoB.TabIndex = 2;

            // txtMajor
            txtMajor.Location = new Point(139, 179);
            txtMajor.Name = "txtMajor";
            txtMajor.Size = new Size(100, 23);
            txtMajor.TabIndex = 1;

            // btnDisplayStudent
            btnDisplayStudent.Location = new Point(28, 269);
            btnDisplayStudent.Name = "btnDisplayStudent";
            btnDisplayStudent.Size = new Size(75, 23);
            btnDisplayStudent.TabIndex = 0;
            btnDisplayStudent.Text = "Display Student";
            btnDisplayStudent.UseVisualStyleBackColor = true;

            // Form1
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnDisplayStudent);
            Controls.Add(txtMajor);
            Controls.Add(txtDoB);
            Controls.Add(txtLastName);
            Controls.Add(txtFirstName);
            Controls.Add(lblMajor);
            Controls.Add(lblDoB);
            Controls.Add(lblLastName);
            Controls.Add(lblFirstName);
            Controls.Add(lblStudentID);
            Controls.Add(txtStudentID);
            Controls.Add(dataGridViewStudent);
            Controls.Add(btnExit);
            Controls.Add(btnClear);
            Controls.Add(btnDelete);
            Controls.Add(btnModify);
            Controls.Add(btnAdd);
            Name = "Form1";
            Text = "Student Database App";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewStudent).EndInit();
            ResumeLayout(false);
            PerformLayout();

            btnAdd.Click += btnAdd_Click;
            btnModify.Click += btnModify_Click;
            btnDelete.Click += btnDelete_Click;
            btnClear.Click += btnClear_Click;
            btnExit.Click += btnExit_Click;
            btnDisplayStudent.Click += btnDisplayStudents_Click;
        }

        private Button btnAdd;
        private Button btnModify;
        private Button btnDelete;
        private Button btnClear;
        private Button btnExit;
        private DataGridView dataGridViewStudent;
        private TextBox txtStudentID;
        private Label lblStudentID;
        private Label lblFirstName;
        private Label lblLastName;
        private Label lblDoB;
        private Label lblMajor;
        private TextBox txtFirstName;
        private TextBox txtLastName;
        private TextBox txtDoB;
        private TextBox txtMajor;
        private Button btnDisplayStudent;
    }
}
